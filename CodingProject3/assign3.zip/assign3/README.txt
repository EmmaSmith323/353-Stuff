Emma Smith
6554044959

Used the deterlab Ubuntu machines.
Compile by using the command make.
I am using a late day with penalty.
There is quite a bit printed to console, just ignore it.